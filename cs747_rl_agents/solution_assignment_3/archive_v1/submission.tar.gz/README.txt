I assume all dependencies as stated in the problem statement
	are already installed.

Simply run the following commands to generate the plots
	and weights, or to test the learned weights.
Train for task1: python mountain_car.py --task T1 --train 1
Train for task2: python mountain_car.py --task T2 --train 1
Test for task1: python mountain_car.py --task T1 --train 0
Test for task2: python mountain_car.py --task T2 --train 0

Appropriate jpg and npy files will be generated for training
	and it should take at most 10 minutes.